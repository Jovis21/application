package jFrames;

import Classes.Book;
import Classes.Clothing;
import Classes.Daily;
import Classes.Inventory;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class InventoryInterface extends javax.swing.JFrame {

    public InventoryInterface() {
        initComponents();
    }
    DefaultTableModel model1;
    DefaultTableModel model2;
    DefaultTableModel model3;
    Inventory database;
    LinkedList<Inventory> list = new LinkedList<>();
    double price;
    int itemCode0;
    String category;

    private void save() throws IOException {

        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File("D:"));
        int retrivel = chooser.showSaveDialog(null);

        if (retrivel == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile() + ".txt")) {
                PrintWriter writeStream = new PrintWriter(fw);
                for (Inventory database4 : list) {
                    if (database4.getCategory().equals("Books")) {
                        writeStream.println(database4.getCategory());
                        writeStream.println(database4.getItemCode());
                        writeStream.println(database4.getPrice());
                        writeStream.println(database4.getAuthor());
                        writeStream.println(database4.getTitle());
                        writeStream.println(database4.getPublisher());
                        writeStream.println(database4.getYear());
                        writeStream.println(database4.getQuantity());

                    } else if (database4.getCategory().equals("Clothing")) {
                        writeStream.println(database4.getCategory());
                        writeStream.println(database4.getItemCode());
                        writeStream.println(database4.getPrice());
                        writeStream.println(database4.getBrand());
                        writeStream.println(database4.getGender());
                        writeStream.println(database4.getClothingCategory());
                        writeStream.println(database4.getDescription());

                    } else {
                        writeStream.println(database4.getCategory());
                        writeStream.println(database4.getItemCode());
                        writeStream.println(database4.getName());
                        writeStream.println(database4.getPrice());
                        writeStream.println(database4.getDailyCategory());
                    }

                }
                fw.close();
            }
        }

    }

    public void resetDaily() {
        dailyItemCodeTF.setText("");
        dailyItemPriceTF.setText("");
        dailyNameTF.setText("");
        message5.setText("");
        message6.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        authorTF = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        titleTF = new javax.swing.JTextField();
        yearTF = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        publisherTF = new javax.swing.JTextField();
        addBook = new javax.swing.JButton();
        editBook = new javax.swing.JButton();
        resetBook = new javax.swing.JButton();
        bookItemCodeTF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        bookPriceTF = new javax.swing.JTextField();
        message1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        bookQuantityTF = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookTable = new javax.swing.JTable();
        displayBook = new javax.swing.JButton();
        searchBook = new javax.swing.JButton();
        deleteBook = new javax.swing.JButton();
        searchBookTF = new javax.swing.JTextField();
        message2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        descriptionTF = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        brandTF = new javax.swing.JTextField();
        addBTN1 = new javax.swing.JButton();
        editBTN1 = new javax.swing.JButton();
        resetBTN1 = new javax.swing.JButton();
        clothItemTF = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        clothPriceTF = new javax.swing.JTextField();
        message3 = new javax.swing.JLabel();
        clothesGenderCB = new javax.swing.JComboBox<>();
        clothesCategoryCB = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        clothesTableTB = new javax.swing.JTable();
        displayBTN1 = new javax.swing.JButton();
        searchBTN1 = new javax.swing.JButton();
        deleteBTN1 = new javax.swing.JButton();
        searchClothTF = new javax.swing.JTextField();
        message4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        dailyNameTF = new javax.swing.JTextField();
        dailyAddBTN = new javax.swing.JButton();
        dailyEditBTN = new javax.swing.JButton();
        resetBTN2 = new javax.swing.JButton();
        dailyItemCodeTF = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        dailyItemPriceTF = new javax.swing.JTextField();
        message5 = new javax.swing.JLabel();
        dailyCategoryCB = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        dailyTable = new javax.swing.JTable();
        searchDailyTF = new javax.swing.JTextField();
        deleteBTN2 = new javax.swing.JButton();
        searchBTN2 = new javax.swing.JButton();
        displayBTN2 = new javax.swing.JButton();
        message6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        openM = new javax.swing.JMenuItem();
        saveM = new javax.swing.JMenuItem();
        exitM = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.lightGray, new java.awt.Color(153, 153, 153), java.awt.Color.darkGray, new java.awt.Color(102, 102, 102)));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBackground(new java.awt.Color(230, 224, 224));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Author");

        authorTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Title");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Year");

        titleTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        yearTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Publisher");

        publisherTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        addBook.setBackground(new java.awt.Color(204, 204, 255));
        addBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addBook.setForeground(new java.awt.Color(255, 51, 0));
        addBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479357_flat-style-circle-add.png"))); // NOI18N
        addBook.setText("ADD");
        addBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBookActionPerformed(evt);
            }
        });

        editBook.setBackground(new java.awt.Color(204, 204, 255));
        editBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        editBook.setForeground(new java.awt.Color(255, 51, 0));
        editBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479636_circle-edit-article.png"))); // NOI18N
        editBook.setText("EDIT");
        editBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBookActionPerformed(evt);
            }
        });

        resetBook.setBackground(new java.awt.Color(204, 204, 255));
        resetBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        resetBook.setForeground(new java.awt.Color(255, 51, 0));
        resetBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479779_flat-style-circle-edit.png"))); // NOI18N
        resetBook.setText("RESET");
        resetBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBookActionPerformed(evt);
            }
        });

        bookItemCodeTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Item Code");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Price");

        bookPriceTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        message1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message1.setForeground(new java.awt.Color(255, 0, 0));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Quantity");

        bookQuantityTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(message1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addComponent(publisherTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel1))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                    .addComponent(bookItemCodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(bookPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(yearTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel14)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(authorTF)
                            .addComponent(titleTF)
                            .addComponent(bookQuantityTF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(addBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(resetBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(titleTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addBook))
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bookItemCodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(bookPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(editBook)
                            .addComponent(authorTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(resetBook)
                                    .addComponent(bookQuantityTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel14)
                                .addGap(3, 3, 3))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(publisherTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(yearTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(message1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE)
                .addContainerGap())
        );

        bookTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Author", "Title", "Publisher", "Year", "Price", "Quantity"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        bookTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(bookTable);
        if (bookTable.getColumnModel().getColumnCount() > 0) {
            bookTable.getColumnModel().getColumn(2).setMinWidth(100);
            bookTable.getColumnModel().getColumn(2).setMaxWidth(100);
            bookTable.getColumnModel().getColumn(5).setMinWidth(50);
            bookTable.getColumnModel().getColumn(5).setMaxWidth(60);
            bookTable.getColumnModel().getColumn(5).setHeaderValue("Price");
            bookTable.getColumnModel().getColumn(6).setMinWidth(50);
            bookTable.getColumnModel().getColumn(6).setMaxWidth(60);
            bookTable.getColumnModel().getColumn(6).setHeaderValue("Quantity");
        }

        displayBook.setBackground(new java.awt.Color(204, 204, 255));
        displayBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        displayBook.setForeground(new java.awt.Color(255, 51, 0));
        displayBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484804_computer.png"))); // NOI18N
        displayBook.setText("DISPLAY");
        displayBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayBookActionPerformed(evt);
            }
        });

        searchBook.setBackground(new java.awt.Color(204, 204, 255));
        searchBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        searchBook.setForeground(new java.awt.Color(255, 51, 0));
        searchBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484946_icon-111-search.png"))); // NOI18N
        searchBook.setText("SEARCH");
        searchBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookActionPerformed(evt);
            }
        });

        deleteBook.setBackground(new java.awt.Color(204, 204, 255));
        deleteBook.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteBook.setForeground(new java.awt.Color(255, 51, 0));
        deleteBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484886_error.png"))); // NOI18N
        deleteBook.setText("DELETE");
        deleteBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBookActionPerformed(evt);
            }
        });

        searchBookTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        searchBookTF.setForeground(new java.awt.Color(204, 204, 204));
        searchBookTF.setText("Item Code...");
        searchBookTF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchBookTFMouseClicked(evt);
            }
        });

        message2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message2.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(displayBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(message2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(searchBookTF, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE))
                .addGap(0, 273, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(displayBook)
                    .addComponent(searchBook)
                    .addComponent(deleteBook)
                    .addComponent(searchBookTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(message2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Book", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel6.setBackground(new java.awt.Color(230, 224, 224));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Category");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Gender");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Description");

        descriptionTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Brand");

        brandTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        addBTN1.setBackground(new java.awt.Color(204, 204, 255));
        addBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addBTN1.setForeground(new java.awt.Color(255, 51, 0));
        addBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479357_flat-style-circle-add.png"))); // NOI18N
        addBTN1.setText("ADD");
        addBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBTN1ActionPerformed(evt);
            }
        });

        editBTN1.setBackground(new java.awt.Color(204, 204, 255));
        editBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        editBTN1.setForeground(new java.awt.Color(255, 51, 0));
        editBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479636_circle-edit-article.png"))); // NOI18N
        editBTN1.setText("EDIT");
        editBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBTN1ActionPerformed(evt);
            }
        });

        resetBTN1.setBackground(new java.awt.Color(204, 204, 255));
        resetBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        resetBTN1.setForeground(new java.awt.Color(255, 51, 0));
        resetBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479779_flat-style-circle-edit.png"))); // NOI18N
        resetBTN1.setText("RESET");
        resetBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBTN1ActionPerformed(evt);
            }
        });

        clothItemTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Item Code");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setText("Price");

        clothPriceTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        message3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message3.setForeground(new java.awt.Color(255, 0, 0));

        clothesGenderCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male ", "Female" }));

        clothesCategoryCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "T-Shirt", "Shirt", "Jeans", "Pants", "Shoes" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(brandTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                            .addComponent(clothItemTF, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(clothPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel8)))
                    .addComponent(descriptionTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(clothesGenderCB, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clothesCategoryCB, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(addBTN1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editBTN1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(resetBTN1))
                    .addComponent(message3, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(clothesGenderCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(clothesCategoryCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(clothItemTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(clothPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(message3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(brandTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(descriptionTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addBTN1)
                    .addComponent(editBTN1)
                    .addComponent(resetBTN1))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        clothesTableTB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Brand", "Gender", "Category", "Description", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        clothesTableTB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clothesTableTBMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(clothesTableTB);
        if (clothesTableTB.getColumnModel().getColumnCount() > 0) {
            clothesTableTB.getColumnModel().getColumn(2).setMinWidth(100);
            clothesTableTB.getColumnModel().getColumn(2).setMaxWidth(100);
        }

        displayBTN1.setBackground(new java.awt.Color(204, 204, 255));
        displayBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        displayBTN1.setForeground(new java.awt.Color(255, 51, 0));
        displayBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484804_computer.png"))); // NOI18N
        displayBTN1.setText("DISPLAY");
        displayBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayBTN1ActionPerformed(evt);
            }
        });

        searchBTN1.setBackground(new java.awt.Color(204, 204, 255));
        searchBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        searchBTN1.setForeground(new java.awt.Color(255, 51, 0));
        searchBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484946_icon-111-search.png"))); // NOI18N
        searchBTN1.setText("SEARCH");
        searchBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBTN1ActionPerformed(evt);
            }
        });

        deleteBTN1.setBackground(new java.awt.Color(204, 204, 255));
        deleteBTN1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteBTN1.setForeground(new java.awt.Color(255, 51, 0));
        deleteBTN1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484886_error.png"))); // NOI18N
        deleteBTN1.setText("DELETE");
        deleteBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBTN1ActionPerformed(evt);
            }
        });

        searchClothTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        searchClothTF.setForeground(new java.awt.Color(204, 204, 204));
        searchClothTF.setText("Item Code...");
        searchClothTF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchClothTFMouseClicked(evt);
            }
        });
        searchClothTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchClothTFActionPerformed(evt);
            }
        });

        message4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message4.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane2)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(displayBTN1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteBTN1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchBTN1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(message4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(searchClothTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(displayBTN1)
                    .addComponent(searchBTN1)
                    .addComponent(deleteBTN1)
                    .addComponent(searchClothTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(message4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Clothes", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel7.setBackground(new java.awt.Color(230, 224, 224));
        jPanel7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Category");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("Name");

        dailyNameTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        dailyAddBTN.setBackground(new java.awt.Color(204, 204, 255));
        dailyAddBTN.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        dailyAddBTN.setForeground(new java.awt.Color(255, 51, 0));
        dailyAddBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479357_flat-style-circle-add.png"))); // NOI18N
        dailyAddBTN.setText("ADD");
        dailyAddBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dailyAddBTNActionPerformed(evt);
            }
        });

        dailyEditBTN.setBackground(new java.awt.Color(204, 204, 255));
        dailyEditBTN.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        dailyEditBTN.setForeground(new java.awt.Color(255, 51, 0));
        dailyEditBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479636_circle-edit-article.png"))); // NOI18N
        dailyEditBTN.setText("EDIT");
        dailyEditBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dailyEditBTNActionPerformed(evt);
            }
        });

        resetBTN2.setBackground(new java.awt.Color(204, 204, 255));
        resetBTN2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        resetBTN2.setForeground(new java.awt.Color(255, 51, 0));
        resetBTN2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495479779_flat-style-circle-edit.png"))); // NOI18N
        resetBTN2.setText("RESET");
        resetBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBTN2ActionPerformed(evt);
            }
        });

        dailyItemCodeTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setText("Item Code");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel18.setText("Price");

        dailyItemPriceTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        message5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message5.setForeground(new java.awt.Color(255, 0, 0));

        dailyCategoryCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Stationary", "Personal Hygine", "Paper/Plastic", "Cleaning Products" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel16)))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dailyNameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                    .addComponent(dailyItemCodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel18)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(dailyItemPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(92, 92, 92)))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(dailyCategoryCB, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(204, 204, 204))))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(message5, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dailyEditBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dailyAddBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(resetBTN2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel17))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(dailyItemCodeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel18)
                                .addComponent(dailyItemPriceTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(dailyNameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dailyCategoryCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(message5, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(dailyAddBTN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dailyEditBTN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(resetBTN2)))
                .addGap(0, 3, Short.MAX_VALUE))
        );

        dailyTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Name", "Category", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        dailyTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dailyTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(dailyTable);

        searchDailyTF.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        deleteBTN2.setBackground(new java.awt.Color(204, 204, 255));
        deleteBTN2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteBTN2.setForeground(new java.awt.Color(255, 51, 0));
        deleteBTN2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484886_error.png"))); // NOI18N
        deleteBTN2.setText("DELETE");
        deleteBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBTN2ActionPerformed(evt);
            }
        });

        searchBTN2.setBackground(new java.awt.Color(204, 204, 255));
        searchBTN2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        searchBTN2.setForeground(new java.awt.Color(255, 51, 0));
        searchBTN2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484946_icon-111-search.png"))); // NOI18N
        searchBTN2.setText("SEARCH");
        searchBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBTN2ActionPerformed(evt);
            }
        });

        displayBTN2.setBackground(new java.awt.Color(204, 204, 255));
        displayBTN2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        displayBTN2.setForeground(new java.awt.Color(255, 51, 0));
        displayBTN2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495484804_computer.png"))); // NOI18N
        displayBTN2.setText("DISPLAY");
        displayBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayBTN2ActionPerformed(evt);
            }
        });

        message6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        message6.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane3)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(displayBTN2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteBTN2)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(message6, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchBTN2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchDailyTF, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 273, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(displayBTN2)
                    .addComponent(searchBTN2)
                    .addComponent(deleteBTN2)
                    .addComponent(searchDailyTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(message6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Daily", jPanel3);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 863, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
        );

        jMenu1.setText("File");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        openM.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.ALT_MASK));
        openM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495485047_Open.png"))); // NOI18N
        openM.setText("Open...");
        openM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMActionPerformed(evt);
            }
        });
        jMenu1.add(openM);

        saveM.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK));
        saveM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495485121_Save.png"))); // NOI18N
        saveM.setText("Save");
        saveM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMActionPerformed(evt);
            }
        });
        jMenu1.add(saveM);

        exitM.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_MASK));
        exitM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jFrames/icons/1495485777_sign-emergency-code-sos_14.png"))); // NOI18N
        exitM.setText("Exit");
        exitM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMActionPerformed(evt);
            }
        });
        jMenu1.add(exitM);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMActionPerformed
     System.exit(0);
    }//GEN-LAST:event_exitMActionPerformed

    private void addBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBookActionPerformed
        addBook();
    }//GEN-LAST:event_addBookActionPerformed

    private void displayBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayBookActionPerformed
        displayBook();
    }//GEN-LAST:event_displayBookActionPerformed

    private void resetBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBookActionPerformed
        resetBook();
    }//GEN-LAST:event_resetBookActionPerformed

    private void bookTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookTableMouseClicked
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        model1 = (DefaultTableModel) bookTable.getModel();
        bookItemCodeTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 0).toString());
        authorTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 1).toString());
        titleTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 2).toString());
        publisherTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 3).toString());
        yearTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 4).toString());
        bookPriceTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 5).toString());
        bookQuantityTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 6).toString());

    }//GEN-LAST:event_bookTableMouseClicked

    private void editBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBookActionPerformed
        edit();
    }//GEN-LAST:event_editBookActionPerformed

    private void deleteBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBookActionPerformed
        deleteBook();
    }//GEN-LAST:event_deleteBookActionPerformed

    private void searchBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBookActionPerformed
        searchBook();
    }//GEN-LAST:event_searchBookActionPerformed

    private void searchBookTFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBookTFMouseClicked
        searchBookTF.setText("");
        searchBookTF.setForeground(Color.BLACK);
    }//GEN-LAST:event_searchBookTFMouseClicked

    private void addBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBTN1ActionPerformed
        addClothes();
        resetClothes();
    }//GEN-LAST:event_addBTN1ActionPerformed

    private void displayBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayBTN1ActionPerformed
        displayClothes();
        resetClothes();
    }//GEN-LAST:event_displayBTN1ActionPerformed

    private void clothesTableTBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clothesTableTBMouseClicked
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        model2 = (DefaultTableModel) clothesTableTB.getModel();
        clothItemTF.setText(model2.getValueAt(clothesTableTB.getSelectedRow(), 0).toString());
        brandTF.setText(model2.getValueAt(clothesTableTB.getSelectedRow(), 1).toString());
        clothesGenderCB.setSelectedItem(model2.getValueAt(clothesTableTB.getSelectedRow(), 2).toString());
        clothesCategoryCB.setSelectedItem(model2.getValueAt(clothesTableTB.getSelectedRow(), 3).toString());
        descriptionTF.setText(model2.getValueAt(clothesTableTB.getSelectedRow(), 4).toString());
        clothPriceTF.setText(model2.getValueAt(clothesTableTB.getSelectedRow(), 5).toString());

    }//GEN-LAST:event_clothesTableTBMouseClicked

    private void editBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBTN1ActionPerformed
        try {
            String brand;
            String description;
            String gender;
            String subCategory;
            model2 = (DefaultTableModel) clothesTableTB.getModel();
            clothItemTF.setText(model2.getValueAt(clothesTableTB.getSelectedRow(), 0).toString());
            itemCode0 = Integer.parseInt(clothItemTF.getText());

            if (clothPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Cloth price is not specified.");
            }
            price = Double.parseDouble(clothPriceTF.getText());
            brand = brandTF.getText();
            if (brand.isEmpty()) {
                throw new IllegalArgumentException("Brand is not specified.");
            }
            description = descriptionTF.getText();
            if (description.isEmpty()) {
                throw new IllegalArgumentException("Description is not specified.");
            }
            gender = clothesGenderCB.getSelectedItem().toString();
            subCategory = clothesCategoryCB.getSelectedItem().toString();

            category = "Clothing";

            for (Inventory info1 : list) {
                if (info1.getItemCode() == itemCode0) {
                    info1.setItemCode(itemCode0);
                    info1.setPrice(price);
                    info1.setBrand(brand);
                    info1.setGender(gender);
                    info1.setClothingCategory(subCategory);

                }
            }
            JOptionPane.showMessageDialog(this, "Information has editted successfully.");
            displayClothes();
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "Please choose from the table");
            message3.setText("Plese choose from the table.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid Input");
            message3.setText("Invalid input.");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "" + e.getMessage());
            message3.setText("" + e.getMessage());
        }
    }//GEN-LAST:event_editBTN1ActionPerformed

    private void deleteBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBTN1ActionPerformed
        message3.setText("");
        message4.setText("");
        if (clothesTableTB.getSelectedRow() == -1) {
            if (clothesTableTB.getRowCount() == 0) {
                message4.setText("The table is empty.");
            } else {
                message4.setText("You must select an item from table.");
            }
        } else {
            int itemCode = Integer.parseInt(model2.getValueAt(clothesTableTB.getSelectedRow(), 0).toString());
            for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                Inventory items = iter.next();
                if (items.getItemCode() == itemCode) {
                    iter.remove();
                    model2.removeRow(clothesTableTB.getSelectedRow());
                }

            }
        }

        resetClothes();
    }//GEN-LAST:event_deleteBTN1ActionPerformed

    private void searchClothTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchClothTFActionPerformed
        searchClothTF.setText("");
        searchClothTF.setForeground(Color.BLACK);
    }//GEN-LAST:event_searchClothTFActionPerformed

    private void searchBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBTN1ActionPerformed
        message4.setText("");
        message4.setText("");
        int itemCode;
        try {

            if (!list.isEmpty()) {
                itemCode = Integer.parseInt(searchClothTF.getText());
                int rc = model2.getRowCount();
                if (searchClothTF.getText().isEmpty()) {
                    throw new IllegalArgumentException("Item code is not specified");
                }

                boolean found = false;
                for (Inventory data1 : list) {
                    if (itemCode == data1.getItemCode() && data1.getCategory().equals("Clothing")) {
                        for (int i = 0; i < rc; i++) {
                            model2.removeRow(0);
                        }
                        model2.addRow(new Object[]{data1.getItemCode(), data1.getBrand(), data1.getGender(), data1.getCategory(), data1.getDescription()});
                        found = true;
                    }
                }
                if (found == false) {
                    throw new IllegalArgumentException("Item is not found.");
                }
            } else {
                throw new IllegalArgumentException("The table is empty.");
            }
        } catch (NumberFormatException ex) {
            message4.setText("Invalid item code.");
        } catch (IllegalArgumentException ex) {
            message4.setText("" + ex.getMessage());
        }
    }//GEN-LAST:event_searchBTN1ActionPerformed

    private void dailyAddBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dailyAddBTNActionPerformed
        try {
            String name;
            String subCategory;

            if (dailyItemCodeTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Item code is not specified.");
            }
            itemCode0 = Integer.parseInt(dailyItemCodeTF.getText());
            for (Inventory database3 : list) {
                if (database3.getItemCode() == itemCode0) {
                    throw new IllegalArgumentException("This item code is already taken");
                }
            }
            if (dailyItemPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Cloth price is not specified.");
            }
            price = Double.parseDouble(dailyItemPriceTF.getText());
            name = dailyNameTF.getText();
            if (name.isEmpty()) {
                throw new IllegalArgumentException("Brand title is not specified.");
            }

            subCategory = dailyCategoryCB.getSelectedItem().toString();

            category = "Daily";
            database = new Daily(price, category, itemCode0, name, subCategory);
            list.add(database);
            JOptionPane.showMessageDialog(this, "Information succesfully entered.");
            resetDaily();
        } catch (NumberFormatException ex) {
            message5.setText("Invalid Input");
        } catch (IllegalArgumentException ex) {
            message5.setText("" + ex.getMessage());
        }
    }//GEN-LAST:event_dailyAddBTNActionPerformed

    private void resetBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBTN2ActionPerformed
        resetDaily();
    }//GEN-LAST:event_resetBTN2ActionPerformed

    private void displayBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayBTN2ActionPerformed
        message5.setText("");
        message6.setText("");
        if (!list.isEmpty()) {
            model3 = (DefaultTableModel) dailyTable.getModel();
            int rc1 = model3.getRowCount();
            for (int i = 0; i < rc1; i++) {
                model3.removeRow(0);
            }
            for (Inventory data1 : list) {
                if (data1.getCategory().equals("Daily")) {
                    model3.addRow(new Object[]{data1.getItemCode(), data1.getName(), data1.getDailyCategory(), data1.getPrice()});
                }
            }
        } else {
            message6.setText("Error! List is empty.");
        }
        resetDaily();
    }//GEN-LAST:event_displayBTN2ActionPerformed

    private void dailyTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dailyTableMouseClicked
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        model3 = (DefaultTableModel) dailyTable.getModel();
        dailyItemCodeTF.setText(model3.getValueAt(dailyTable.getSelectedRow(), 0).toString());
        dailyNameTF.setText(model3.getValueAt(dailyTable.getSelectedRow(), 1).toString());
        dailyCategoryCB.setSelectedItem(model3.getValueAt(dailyTable.getSelectedRow(), 2).toString());
        dailyItemPriceTF.setText(model3.getValueAt(dailyTable.getSelectedRow(), 3).toString());
    }//GEN-LAST:event_dailyTableMouseClicked

    private void deleteBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBTN2ActionPerformed
        message5.setText("");
        message6.setText("");
        if (dailyTable.getSelectedRow() == -1) {
            if (dailyTable.getRowCount() == 0) {
                message5.setText("The table is empty.");
            } else {
                message6.setText("You must select an item from table.");
            }
        } else {
            int itemCode = Integer.parseInt(model3.getValueAt(dailyTable.getSelectedRow(), 0).toString());
            for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                Inventory items = iter.next();
                if (items.getItemCode() == itemCode) {
                    iter.remove();
                    model3.removeRow(dailyTable.getSelectedRow());
                }

            }
        }
        resetDaily();
    }//GEN-LAST:event_deleteBTN2ActionPerformed

    private void searchBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBTN2ActionPerformed
        message6.setText("");
        message6.setText("");
        int itemCode;
        try {

            if (!list.isEmpty()) {
                itemCode = Integer.parseInt(searchDailyTF.getText());
                int rc = model3.getRowCount();
                if (searchDailyTF.getText().isEmpty()) {
                    throw new IllegalArgumentException("Item code is not specified");
                }

                boolean found = false;
                for (Inventory data1 : list) {
                    if (itemCode == data1.getItemCode() && data1.getCategory().equals("Daily")) {
                        for (int i = 0; i < rc; i++) {
                            model3.removeRow(0);
                        }
                        model3.addRow(new Object[]{data1.getItemCode(), data1.getName(), data1.getDailyCategory(), data1.getPrice()});
                        found = true;
                    }
                }
                if (found == false) {
                    throw new IllegalArgumentException("Item is not found.");
                }
            } else {
                throw new IllegalArgumentException("The table is empty.");
            }
        } catch (NumberFormatException ex) {
            message6.setText("Invalid item code.");
        } catch (IllegalArgumentException ex) {
            message6.setText("" + ex.getMessage());
        }
    }//GEN-LAST:event_searchBTN2ActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed

    }//GEN-LAST:event_jMenu1ActionPerformed

    private void openMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMActionPerformed
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.showOpenDialog(null);
            File inFile = chooser.getSelectedFile();
            FileReader fileReader;
            BufferedReader bufReader;
            String itemCode;
            int itemCodeI;
            String category2;
            double priceBook;
            String author;
            String title;
            String publisher;
            int year;
            int quantity;
            double priceCloth;
            String brand;
            String gender;
            String clothingCategory;
            String description;
            String name;
            double price33;
            String dailyCategory;
            fileReader = new FileReader(inFile);
            bufReader = new BufferedReader(fileReader);
            
            category2 = bufReader.readLine();
            while (category2 != null) {

                switch (category2) {
                    case "Books":
                        itemCode = bufReader.readLine();
                        itemCodeI = Integer.parseInt(itemCode);
                        for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                            Inventory database1 = iter.next();
                            if (database1.getItemCode() == itemCodeI) {
                                iter.remove();
                            }
                        }
                        String priceBook2 = bufReader.readLine();
                        priceBook = Double.parseDouble(priceBook2);
                        author = bufReader.readLine();
                        title = bufReader.readLine();
                        publisher = bufReader.readLine();
                        String yearS = bufReader.readLine();
                        year = Integer.parseInt(yearS);
                        String quantityS = bufReader.readLine();
                        quantity = Integer.parseInt(quantityS);
                        database = new Book(priceBook, category2, itemCodeI, title, author, publisher, year, quantity);
                        list.add(database);
                        category2 = bufReader.readLine();
                        break;
                    case "Clothing":
                        itemCode = bufReader.readLine();
                        itemCodeI = Integer.parseInt(itemCode);
                        for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                            Inventory database1 = iter.next();
                            if (database1.getItemCode() == itemCodeI) {
                                iter.remove();
                            }
                        }
                        priceCloth = Double.parseDouble(bufReader.readLine());
                        brand = bufReader.readLine();
                        gender = bufReader.readLine();
                        clothingCategory = bufReader.readLine();
                        description = bufReader.readLine();
                        database = new Clothing(priceCloth, category2, itemCodeI, gender, description, brand, clothingCategory);
                        list.add(database);
                        category2 = bufReader.readLine();
                        break;
                    default:
                        itemCode = bufReader.readLine();
                        itemCodeI = Integer.parseInt(itemCode);
                        for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                            Inventory database1 = iter.next();
                            if (database1.getItemCode() == itemCodeI) {
                                iter.remove();
                            }
                        }
                        name = bufReader.readLine();
                        price33 = Double.parseDouble(bufReader.readLine());
                        dailyCategory = bufReader.readLine();
                        database = new Daily(price33, category2, itemCodeI, name, dailyCategory);
                        list.add(database);
                        category2 = bufReader.readLine();
                        break;

                }

            }
            bufReader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(InventoryInterface.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(InventoryInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_openMActionPerformed

    private void saveMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMActionPerformed
        try {
            save();
        } catch (IOException ex) {
            Logger.getLogger(InventoryInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_saveMActionPerformed

    private void dailyEditBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dailyEditBTNActionPerformed
        try {
            String name;
            String subCategory;
            model3 = (DefaultTableModel) dailyTable.getModel();
            dailyItemCodeTF.setText(model3.getValueAt(dailyTable.getSelectedRow(), 0).toString());
            itemCode0 = Integer.parseInt(dailyItemCodeTF.getText());
            //  itemCode0 = Integer.parseInt(model3.getValueAt(dailyTable.getSelectedRow(), 0).toString());

            if (dailyItemPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Price is not specified.");
            }
            price = Double.parseDouble(dailyItemPriceTF.getText());
            name = dailyNameTF.getText();
            if (name.isEmpty()) {
                throw new IllegalArgumentException("Name is not specified.");
            }

            subCategory = dailyCategoryCB.getSelectedItem().toString();

            category = "Daily";

            for (Inventory info1 : list) {
                if (info1.getItemCode() == itemCode0) {
                    info1.setItemCode(itemCode0);
                    info1.setPrice(price);
                    info1.setName(name);
                    info1.setDailyCategory(subCategory);

                }
            }
            JOptionPane.showMessageDialog(this, "Information has editted successfully.");
            displayDaily();
        } catch (ArrayIndexOutOfBoundsException ex) {
            message5.setText("Plese choose from the table.");
        } catch (NumberFormatException e) {
            message5.setText("Invalid input.");
        } catch (IllegalArgumentException e) {
            message5.setText("" + e.getMessage());
        }
    }//GEN-LAST:event_dailyEditBTNActionPerformed

    private void searchClothTFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchClothTFMouseClicked
        searchClothTF.setText("");
        searchClothTF.setForeground(Color.BLACK);
    }//GEN-LAST:event_searchClothTFMouseClicked

    private void resetBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBTN1ActionPerformed
     resetClothes();
    }//GEN-LAST:event_resetBTN1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InventoryInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InventoryInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InventoryInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InventoryInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new InventoryInterface().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBTN1;
    private javax.swing.JButton addBook;
    private javax.swing.JTextField authorTF;
    private javax.swing.JTextField bookItemCodeTF;
    private javax.swing.JTextField bookPriceTF;
    private javax.swing.JTextField bookQuantityTF;
    private javax.swing.JTable bookTable;
    private javax.swing.JTextField brandTF;
    private javax.swing.JTextField clothItemTF;
    private javax.swing.JTextField clothPriceTF;
    private javax.swing.JComboBox<String> clothesCategoryCB;
    private javax.swing.JComboBox<String> clothesGenderCB;
    private javax.swing.JTable clothesTableTB;
    private javax.swing.JButton dailyAddBTN;
    private javax.swing.JComboBox<String> dailyCategoryCB;
    private javax.swing.JButton dailyEditBTN;
    private javax.swing.JTextField dailyItemCodeTF;
    private javax.swing.JTextField dailyItemPriceTF;
    private javax.swing.JTextField dailyNameTF;
    private javax.swing.JTable dailyTable;
    private javax.swing.JButton deleteBTN1;
    private javax.swing.JButton deleteBTN2;
    private javax.swing.JButton deleteBook;
    private javax.swing.JTextField descriptionTF;
    private javax.swing.JButton displayBTN1;
    private javax.swing.JButton displayBTN2;
    private javax.swing.JButton displayBook;
    private javax.swing.JButton editBTN1;
    private javax.swing.JButton editBook;
    private javax.swing.JMenuItem exitM;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel message1;
    private javax.swing.JLabel message2;
    private javax.swing.JLabel message3;
    private javax.swing.JLabel message4;
    private javax.swing.JLabel message5;
    private javax.swing.JLabel message6;
    private javax.swing.JMenuItem openM;
    private javax.swing.JTextField publisherTF;
    private javax.swing.JButton resetBTN1;
    private javax.swing.JButton resetBTN2;
    private javax.swing.JButton resetBook;
    private javax.swing.JMenuItem saveM;
    private javax.swing.JButton searchBTN1;
    private javax.swing.JButton searchBTN2;
    private javax.swing.JButton searchBook;
    private javax.swing.JTextField searchBookTF;
    private javax.swing.JTextField searchClothTF;
    private javax.swing.JTextField searchDailyTF;
    private javax.swing.JTextField titleTF;
    private javax.swing.JTextField yearTF;
    // End of variables declaration//GEN-END:variables

    private void addBook() {
        try {
            String author;
            String title;
            String publisher;
            int quantity;
            int year;

            if (bookItemCodeTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Item code is not specified.");
            }
            itemCode0 = Integer.parseInt(bookItemCodeTF.getText());
            for (Inventory database : list) {
                if (database.getItemCode() == itemCode0) {
                    throw new IllegalArgumentException("This item code is already taken");
                }
            }
            if (bookPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Book price is not specified.");
            }
            price = Double.parseDouble(bookPriceTF.getText());
            title = titleTF.getText();
            if (title.isEmpty()) {
                throw new IllegalArgumentException("Book title is not specified.");
            }
            author = authorTF.getText();
            if (author.isEmpty()) {
                throw new IllegalArgumentException("Book author is not specified.");
            }
            publisher = publisherTF.getText();
            if (publisher.isEmpty()) {
                throw new IllegalArgumentException("Book buplisher is not specified.");
            }
            if (yearTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Published year is not specified.");
            }
            year = Integer.parseInt(yearTF.getText());
            if (bookQuantityTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Quantity is not specified.");
            }
            quantity = Integer.parseInt(bookQuantityTF.getText());
            category = "Books";
            database = new Book(price, category, itemCode0, title, author, publisher, year, quantity);
            list.add(database);
            JOptionPane.showMessageDialog(this, "Information succesfully entered.");
            resetBook();
        } catch (NumberFormatException ex) {
            message1.setText("Invalid Input");
        } catch (IllegalArgumentException ex) {
            message1.setText("" + ex.getMessage());
        }

    }

    private void displayBook() {
        message1.setText("");
        message2.setText("");
        if (!list.isEmpty()) {
            model1 = (DefaultTableModel) bookTable.getModel();
            int rc1 = model1.getRowCount();
            for (int i = 0; i < rc1; i++) {
                model1.removeRow(0);
            }
            for (Inventory data1 : list) {
                if (data1.getCategory().equals("Books")) {
                    model1.addRow(new Object[]{data1.getItemCode(), data1.getAuthor(), data1.getTitle(), data1.getPublisher(), data1.getYear(), data1.getPrice(), data1.getQuantity()});
                }
            }
        } else {
            message2.setText("Error! List is empty.");
        }
    }

    private void resetBook() {
        bookItemCodeTF.setText("");
        bookPriceTF.setText("");
        bookQuantityTF.setText("");
        publisherTF.setText("");
        titleTF.setText("");
        authorTF.setText("");
        yearTF.setText("");
        message1.setText("");
        message2.setText("");
    }

    private void edit() {
        try {
            String author;
            String title;
            String publisher;
            int quantity;
            int year;
            model1 = (DefaultTableModel) bookTable.getModel();
            bookItemCodeTF.setText(model1.getValueAt(bookTable.getSelectedRow(), 0).toString());
            itemCode0 = Integer.parseInt(bookItemCodeTF.getText());

            if (bookPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Book price is not specified.");
            }
            price = Double.parseDouble(bookPriceTF.getText());
            title = titleTF.getText();
            if (title.isEmpty()) {
                throw new IllegalArgumentException("Book title is not specified.");
            }
            author = authorTF.getText();
            if (author.isEmpty()) {
                throw new IllegalArgumentException("Book author is not specified.");
            }
            publisher = publisherTF.getText();
            if (publisher.isEmpty()) {
                throw new IllegalArgumentException("Book buplisher is not specified.");
            }
            if (yearTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Published year is not specified.");
            }
            year = Integer.parseInt(yearTF.getText());
            if (bookQuantityTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Quantity is not specified.");
            }
            quantity = Integer.parseInt(bookQuantityTF.getText());
            category = "Books";

            for (Inventory info1 : list) {
                if (info1.getItemCode() == itemCode0) {
                    info1.setItemCode(itemCode0);
                    info1.setPrice(price);
                    info1.setAuthor(author);
                    info1.setTitle(title);
                    info1.setYear(year);
                    info1.setQuantity(quantity);
                    info1.setPublisher(publisher);
                }
            }
            JOptionPane.showMessageDialog(this, "Information has editted successfully.");
            displayBook();
        } catch (ArrayIndexOutOfBoundsException ex) {
            message1.setText("Plese choose from the table.");
        } catch (NumberFormatException e) {
            message1.setText("Invalid input.");
        } catch (IllegalArgumentException e) {
            message1.setText("" + e.getMessage());
        }
    }

    private void deleteBook() {
        message1.setText("");
        message2.setText("");
        if (bookTable.getSelectedRow() == -1) {
            if (bookTable.getRowCount() == 0) {
                message2.setText("The table is empty.");
            } else {
                message2.setText("You must select an item from table.");
            }
        } else {
            int itemCode = Integer.parseInt(model1.getValueAt(bookTable.getSelectedRow(), 0).toString());
            for (Iterator<Inventory> iter = list.iterator(); iter.hasNext();) {
                Inventory items = iter.next();
                if (items.getItemCode() == itemCode) {
                    iter.remove();
                    model1.removeRow(bookTable.getSelectedRow());
                }

            }
        }
        resetBook();

    }

    private void searchBook() {
        message1.setText("");
        message1.setText("");
        int itemCode;
        try {

            if (!list.isEmpty()) {
                itemCode = Integer.parseInt(searchBookTF.getText());
                int rc = model1.getRowCount();
                if (searchBookTF.getText().isEmpty()) {
                    throw new IllegalArgumentException("Item code is not specified");
                }

                boolean found = false;
                for (Inventory data1 : list) {
                    if (itemCode == data1.getItemCode() && data1.getCategory().equals("Books")) {
                        for (int i = 0; i < rc; i++) {
                            model1.removeRow(0);
                        }
                        model1.addRow(new Object[]{data1.getItemCode(), data1.getAuthor(), data1.getTitle(), data1.getPublisher(), data1.getYear(), data1.getPrice(), data1.getQuantity()});
                        found = true;
                    }
                }
                if (found == false) {
                    throw new IllegalArgumentException("Item is not found.");
                }
            } else {
                throw new IllegalArgumentException("The stock is empty.");
            }
        } catch (NumberFormatException ex) {
            message2.setText("Invalid item code.");
        } catch (IllegalArgumentException ex) {
            message2.setText("" + ex.getMessage());
        }
    }

    private void addClothes() {
        try {
            String brand;
            String description;
            String gender;
            String subCategory;

            if (clothItemTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Item code is not specified.");
            }
            itemCode0 = Integer.parseInt(clothItemTF.getText());
            for (Inventory database : list) {
                if (database.getItemCode() == itemCode0) {
                    throw new IllegalArgumentException("This item code is already taken");
                }
            }
            if (clothPriceTF.getText().isEmpty()) {
                throw new IllegalArgumentException("Cloth price is not specified.");
            }
            price = Double.parseDouble(clothPriceTF.getText());
            brand = brandTF.getText();
            if (brand.isEmpty()) {
                throw new IllegalArgumentException("Brand title is not specified.");
            }
            description = descriptionTF.getText();
            if (description.isEmpty()) {
                throw new IllegalArgumentException("Book author is not specified.");
            }
            gender = clothesGenderCB.getSelectedItem().toString();
            subCategory = clothesCategoryCB.getSelectedItem().toString();

            category = "Clothing";
            database = new Clothing(price, category, itemCode0, gender, description, brand, subCategory);
            list.add(database);
            JOptionPane.showMessageDialog(this, "Information succesfully entered.");
            resetBook();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Input");
            message3.setText("Invalid Input");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, " " + ex.getMessage());
            message3.setText("" + ex.getMessage());
        }

    }

    private void resetClothes() {
        clothItemTF.setText("");
        clothPriceTF.setText("");
        brandTF.setText("");
        descriptionTF.setText("");
        message3.setText("");
        message4.setText("");

    }

    private void displayDaily() {
        message5.setText("");
        message6.setText("");
        if (!list.isEmpty()) {
            model3 = (DefaultTableModel) dailyTable.getModel();
            int rc1 = model3.getRowCount();
            for (int i = 0; i < rc1; i++) {
                model3.removeRow(0);
            }
            for (Inventory data1 : list) {
                if (data1.getCategory().equals("Daily")) {
                    model3.addRow(new Object[]{data1.getItemCode(), data1.getName(), data1.getDailyCategory(), data1.getPrice()});
                }
            }
        } else {
            message6.setText("Error! List is empty.");
        }
    }

    private void displayClothes() {
        message3.setText("");
        message4.setText("");
        if (!list.isEmpty()) {
            model2 = (DefaultTableModel) clothesTableTB.getModel();
            int rc1 = model2.getRowCount();
            for (int i = 0; i < rc1; i++) {
                model2.removeRow(0);
            }
            for (Inventory data1 : list) {
                if (data1.getCategory().equals("Clothing")) {
                    model2.addRow(new Object[]{data1.getItemCode(), data1.getBrand(), data1.getGender(), data1.getCategory(), data1.getDescription(), data1.getPrice()});
                }
            }
        } else {
            message4.setText("Error! List is empty.");
        }
    }

}
