package Classes;

public abstract class Inventory implements InventoryInterface{

    private  double price;
    private String category;
    private  int itemCode;

    public Inventory(double price, String category, int itemCode) {
        this.price = price;
        this.category = category;
        this.itemCode = itemCode;
    }

    
    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String getCategory() {
        return category;
    }

    @Override
    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public int getItemCode() {
        return itemCode;
    }

    @Override
    public void setItemCode(int itemCode) {
        this.itemCode = itemCode;
    }
    
 
    @Override
    public String getAuthor(){
    return null;
    }

    @Override
    public void setAuthor(String author){
    
    }

    @Override
    public String getTitle(){
    return "";
    }

    @Override
    public void setTitle(String title){
    
    }

    @Override
    public String getPublisher(){
    return "";
    }

    @Override
    public void setPublisher(String publisher){
    
    }

    @Override
    public int getYear(){
    return 0;
    }

    @Override
    public void setYear(int year){
    
    }

    @Override
    public String getGender(){
    return "";
    }

    @Override
    public void setGender(String gender){
    
    }

    @Override
    public String getClothingCategory(){
    return "";
    }

    @Override
    public void setClothingCategory(String clothingCategory){
    
    }

    @Override
    public String getBrand(){
    return "";
    }

    @Override
    public void setBrand(String brand){
    
    }

    @Override
    public String getDescription(){
    return "";
    }

    @Override
    public void setDescription(String description){
    
    }

    @Override
    public String getName(){
    return "";
    }

    @Override
    public void setName(String name){
    
    }
    @Override
    public int getQuantity(){
        return 0;
    }
    @Override
    public void setQuantity(int quantity){
    
    }
    
    @Override
    public String getDailyCategory(){
  return "";
    }

    @Override
    public void setDailyCategory(String dailyCategory){
    
    }
   

}
