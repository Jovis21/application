package Classes;

public interface InventoryInterface {

    public double getPrice();

    public void setPrice(double price);

    public String getCategory();

    public void setCategory(String category);

    public int getItemCode();

    public void setItemCode(int itemCode);

    public String getAuthor();

    public void setAuthor(String author);

    public String getTitle();

    public void setTitle(String title);

    public String getPublisher();

    public void setPublisher(String publisher);

    public int getYear();

    public void setYear(int year);

    public String getGender();

    public void setGender(String gender);

    public String getClothingCategory();

    public void setClothingCategory(String clothingCategory);

    public String getBrand();

    public void setBrand(String brand);

    public String getDescription();

    public void setDescription(String description);

    public String getName();

    public void setName(String name);

    public String getDailyCategory();

    public void setDailyCategory(String dailyCategory);

    public int getQuantity();

    public void setQuantity(int quantity);

}
