package Classes;

public class Daily extends Inventory {

    private String name;
    private String dailyCategory;

    public Daily(double price, String category, int itemCode, String name, String dailyCategory) {
        super(price, category, itemCode);
        this.name = name;
        this.dailyCategory = dailyCategory;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDailyCategory() {
        return dailyCategory;
    }

    @Override
    public void setDailyCategory(String dailyCategory) {
        this.dailyCategory = dailyCategory;
    }

    @Override
    public void setPrice(double price) {
        super.setPrice(price);
    }

    @Override
    public String getCategory() {
        return super.getCategory();
    }

    @Override
    public void setCategory(String category) {
        super.setCategory(category);
    }

    @Override
    public int getItemCode() {
        return super.getItemCode();
    }

    @Override
    public void setItemCode(int itemCode) {
        super.setItemCode(itemCode);
    }

   
}
