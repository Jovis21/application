
package Classes;

public class Book extends Inventory{
    private String title;
    private String author;
    private int year;
    private String publisher;
    private int quantity;
    public Book(double price, String category, int itemCode, String title, String author, String publisher, int year, int quantity) {
        super(price, category, itemCode);
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.quantity =quantity;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
    }
    @Override
    public String getAuthor() {
        return author;
    }

    @Override
    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public int getYear() {
        return year;
    }

    @Override
    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String getPublisher() {
        return publisher;
    }

    @Override
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
     public double getPrice() {
        return super.getPrice();
    }

    @Override
    public void setPrice(double price) {
        super.setPrice(price);
    }

    @Override
    public String getCategory() {
        return super.getCategory();
    }

    @Override
    public void setCategory(String category) {
        super.setCategory(category);
    }

    @Override
    public int getItemCode() {
        return super.getItemCode();
    }

    @Override
    public void setItemCode(int itemCode) {
       super.setItemCode(itemCode);
    }

 



   
 

   
  
    
}
