package Classes;

public class Clothing extends Inventory {

    private String gender;
    private String description;
    private String clothingCategory;
    private String brand;

    public Clothing(double price, String category, int itemCode, String gender, String description, String brand, String clothingCategory) {
        super(price, category, itemCode);
        this.gender = gender;
        this.description = description;
        this.brand = brand;
        this.clothingCategory = clothingCategory;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getClothingCategory() {
        return clothingCategory;
    }
    
    public void setClothingCategory(String clothingCategory) {
        this.clothingCategory = clothingCategory;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public double getPrice() {
        return super.getPrice();
    }
    
    @Override
    public void setPrice(double price) {
        super.setPrice(price);
    }
    
    @Override
    public String getCategory() {
        return super.getCategory();
    }
    
    @Override
    public void setCategory(String category) {
        super.setCategory(category);
    }
    
    @Override
    public int getItemCode() {
        return super.getItemCode();
    }
    
    @Override
    public void setItemCode(int itemCode) {
        super.setItemCode(itemCode);
    }

   
}
